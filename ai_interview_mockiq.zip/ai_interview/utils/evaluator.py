"""
utils/evaluator.py
Score and provide feedback on interview answers using Claude.
Falls back to keyword-based scoring if API not available.
"""

import os
import json
import re


def evaluate_answer(question: str, answer: str, domain: str, q_type: str = "Technical") -> dict:
    """
    Evaluate an answer. Returns dict with:
      score (1-10), feedback (str), strengths (list), improvements (list)
    """
    # Try Claude-based evaluation first
    result = _evaluate_with_claude(question, answer, domain, q_type)
    if result:
        return result

    # Fallback: heuristic scoring
    return _evaluate_heuristic(answer)


def _evaluate_with_claude(question, answer, domain, q_type) -> dict | None:
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        return None

    try:
        import anthropic
        client = anthropic.Anthropic(api_key=api_key)

        prompt = f"""You are a strict but fair technical interviewer for a {domain} role.

Question ({q_type}): {question}
Candidate's answer: {answer[:1200]}

Evaluate this answer rigorously. Consider: correctness, depth, clarity, use of examples.

Respond ONLY with valid JSON, no markdown:
{{
  "score": <integer 1-10>,
  "feedback": "<2-3 sentences of specific, actionable feedback mentioning what was good and what to improve>",
  "strengths": ["<specific strength>", "<specific strength>"],
  "improvements": ["<specific area to improve>"]
}}"""

        msg = client.messages.create(
            model="claude-opus-4-5",
            max_tokens=600,
            messages=[{"role": "user", "content": prompt}]
        )
        raw = msg.content[0].text
        clean = re.sub(r"```json|```", "", raw).strip()
        parsed = json.loads(clean)

        return {
            "score": max(1, min(10, int(parsed.get("score", 6)))),
            "feedback": parsed.get("feedback", "Good attempt."),
            "strengths": parsed.get("strengths", []),
            "improvements": parsed.get("improvements", [])
        }
    except Exception as e:
        print(f"Evaluator error: {e}")
        return None


def _evaluate_heuristic(answer: str) -> dict:
    """
    Simple keyword/length-based heuristic fallback.
    """
    score = 5  # base

    words = answer.split()
    word_count = len(words)

    # Length bonus
    if word_count > 150:
        score += 2
    elif word_count > 80:
        score += 1
    elif word_count < 30:
        score -= 2

    # Technical keyword bonus
    tech_keywords = [
        "example", "because", "therefore", "however", "specifically",
        "implemented", "used", "built", "designed", "optimized",
        "performance", "complexity", "efficient", "trade-off"
    ]
    matches = sum(1 for kw in tech_keywords if kw in answer.lower())
    score += min(matches, 3)

    score = max(1, min(10, score))

    return {
        "score": score,
        "feedback": (
            "Your answer covers the key points. "
            "Consider adding more specific examples from real projects "
            "and explaining your reasoning step by step for a stronger response."
        ),
        "strengths": ["Addressed the question"],
        "improvements": ["Add concrete examples", "Go deeper into technical details"]
    }
