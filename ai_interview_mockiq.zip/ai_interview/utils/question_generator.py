"""
utils/question_generator.py
Generate interview questions and follow-ups using Claude API.
Falls back to curated questions if API key not set.
"""

import os
import json
import re
import anthropic

FALLBACK_QUESTIONS = {
    "Data Analyst": [
        {"text": "Walk me through how you would clean a messy dataset with nulls, duplicates, and wrong data types using Python.", "type": "Technical"},
        {"text": "You're given a SQL table with 10M rows. Write a query to find the top 5 customers by revenue in the last 30 days.", "type": "SQL"},
        {"text": "Explain the difference between INNER JOIN, LEFT JOIN, and FULL OUTER JOIN with a real example.", "type": "SQL"},
        {"text": "How would you detect and handle outliers in a numerical dataset?", "type": "Statistical"},
        {"text": "A stakeholder asks for a dashboard. What metrics would you prioritize and why?", "type": "Behavioral"},
    ],
    "Web Developer": [
        {"text": "Explain the React reconciliation algorithm and why it matters for performance.", "type": "React"},
        {"text": "How does the event loop work in JavaScript? Walk through an example with setTimeout and Promises.", "type": "JavaScript"},
        {"text": "Design a simple REST API for a blog system. What endpoints, methods, and status codes would you use?", "type": "API Design"},
        {"text": "What is CORS and how do you fix it? Explain from both frontend and backend perspective.", "type": "Technical"},
        {"text": "You notice your React app is re-rendering too often. How do you debug and fix it?", "type": "Performance"},
    ],
    "Machine Learning Engineer": [
        {"text": "Explain the bias-variance tradeoff and how you balance it in practice.", "type": "Concept"},
        {"text": "How would you handle a highly imbalanced dataset where only 1% of samples are positive?", "type": "Technical"},
        {"text": "Walk through how gradient descent works. What are common variants and when do you use each?", "type": "Theory"},
        {"text": "You trained a model with 98% accuracy but it performs poorly in production. What went wrong?", "type": "Debugging"},
        {"text": "How would you design an ML pipeline from data collection to model serving?", "type": "System Design"},
    ],
    "Backend Developer": [
        {"text": "Explain the difference between SQL and NoSQL databases. When would you choose each?", "type": "Database"},
        {"text": "How do you design a RESTful API that scales to millions of users?", "type": "System Design"},
        {"text": "What is a race condition and how do you prevent it in a multi-threaded system?", "type": "Concurrency"},
        {"text": "Explain Docker and how containers differ from virtual machines.", "type": "DevOps"},
        {"text": "How would you implement caching in a backend API? What strategies exist?", "type": "Performance"},
    ],
    "DevOps Engineer": [
        {"text": "Explain the difference between Docker and Kubernetes. When would you use Kubernetes?", "type": "Containers"},
        {"text": "Walk through a CI/CD pipeline you would design for a Python microservice.", "type": "CI/CD"},
        {"text": "How do you handle secrets and environment variables securely in production?", "type": "Security"},
        {"text": "What is infrastructure as code? Explain Terraform's approach.", "type": "IaC"},
        {"text": "A service is down. Walk through your incident response process.", "type": "Operations"},
    ],
    "Product Manager": [
        {"text": "How would you prioritize features when engineering, design, and business all want different things?", "type": "Strategy"},
        {"text": "Walk me through how you would define success metrics for a new onboarding flow.", "type": "Metrics"},
        {"text": "A key metric dropped 20% overnight. How do you investigate and respond?", "type": "Analysis"},
        {"text": "How do you write a product requirements document (PRD)? Walk through its key sections.", "type": "Process"},
        {"text": "Tell me about a time you had to kill a feature. How did you make that decision?", "type": "Behavioral"},
    ],
}


def get_client():
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        return None
    return anthropic.Anthropic(api_key=api_key)


def call_claude(prompt: str, max_tokens: int = 1000) -> str:
    """Generic Claude call. Returns text or empty string on failure."""
    client = get_client()
    if not client:
        return ""
    try:
        msg = client.messages.create(
            model="claude-opus-4-5",
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}]
        )
        return msg.content[0].text
    except Exception as e:
        print(f"Claude API error: {e}")
        return ""


def generate_questions(domain: str, skills: list, resume_text: str, n: int = 5) -> list:
    """
    Generate n interview questions tailored to the candidate's skills and resume.
    Falls back to curated questions if API call fails.
    """
    client = get_client()
    if not client:
        return FALLBACK_QUESTIONS.get(domain, FALLBACK_QUESTIONS["Data Analyst"])[:n]

    skills_str = ", ".join(skills[:8]) if skills else domain
    # Truncate resume to keep prompt manageable
    resume_snippet = resume_text[:800].replace("\n", " ")

    prompt = f"""You are a senior technical interviewer for a {domain} role.

Candidate resume snippet: {resume_snippet}
Detected skills: {skills_str}

Generate exactly {n} unique technical interview questions tailored to this candidate.
Mix of: technical depth, practical scenarios, and one behavioral question.
Questions should reference skills and projects visible in their resume when possible.

Respond ONLY with valid JSON array, no markdown, no explanation:
[
  {{"text": "question text here", "type": "Technical|SQL|Behavioral|System Design|etc"}},
  ...
]"""

    raw = call_claude(prompt, max_tokens=1200)
    if not raw:
        return FALLBACK_QUESTIONS.get(domain, FALLBACK_QUESTIONS["Data Analyst"])[:n]

    try:
        clean = re.sub(r"```json|```", "", raw).strip()
        questions = json.loads(clean)
        if isinstance(questions, list) and questions:
            return questions[:n]
    except Exception:
        pass

    return FALLBACK_QUESTIONS.get(domain, FALLBACK_QUESTIONS["Data Analyst"])[:n]


def generate_followup(question: str, answer: str, domain: str) -> str:
    """Generate a follow-up question based on candidate's answer."""
    client = get_client()
    if not client:
        return "Can you give a specific example from a real project where you applied this?"

    prompt = f"""You are interviewing a candidate for a {domain} role.

Original question: {question}
Candidate answered: {answer[:600]}

Generate ONE concise follow-up question that digs deeper into their answer.
Ask about a specific detail they mentioned, a weakness in their approach, or an edge case.
Return ONLY the follow-up question, nothing else."""

    result = call_claude(prompt, max_tokens=200)
    if result and len(result) > 10:
        return result.strip().strip('"')
    return "Can you walk me through a real example from your experience?"
