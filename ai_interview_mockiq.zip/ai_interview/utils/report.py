"""
utils/report.py
Build the final performance report from interview session data.
"""

from collections import Counter


def build_report(name, domain, questions, answers, scores, feedbacks, sentiments, skills):
    """
    Aggregate all interview data into a structured report dict.
    """
    total_q = len(questions)
    total_answered = len(scores)

    if not scores:
        return {"error": "No answers recorded."}

    avg_score = round(sum(scores) / len(scores), 1)

    # Per-question breakdown
    breakdown = []
    for i, q in enumerate(questions):
        if i < len(scores):
            breakdown.append({
                "number": i + 1,
                "question": q["text"],
                "type": q.get("type", "General"),
                "answer": answers[i] if i < len(answers) else "",
                "score": scores[i],
                "feedback": feedbacks[i] if i < len(feedbacks) else "",
                "sentiment": sentiments[i] if i < len(sentiments) else "Neutral",
                "score_color": _score_color(scores[i]),
                "score_bg": _score_bg(scores[i]),
            })

    # Strengths: questions with score >= 7
    strong_qs = [b for b in breakdown if b["score"] >= 7]
    weak_qs = [b for b in breakdown if b["score"] < 6]

    # Top and weakest area
    if scores:
        max_idx = scores.index(max(scores))
        min_idx = scores.index(min(scores))
        strongest_area = questions[max_idx].get("type", "General") if max_idx < len(questions) else "—"
        weakest_area = questions[min_idx].get("type", "General") if min_idx < len(questions) else "—"
    else:
        strongest_area = weakest_area = "—"

    # Dominant sentiment
    sentiment_counts = Counter(sentiments)
    dominant_sentiment = sentiment_counts.most_common(1)[0][0] if sentiments else "Neutral"

    # Grade
    grade, grade_color = _grade(avg_score)

    # Score distribution (for chart)
    score_dist = [b["score"] for b in breakdown]

    # Skill-level tips
    weak_types = list({b["type"] for b in weak_qs})

    return {
        "name": name or "Candidate",
        "domain": domain,
        "skills": skills,
        "total_questions": total_q,
        "total_answered": total_answered,
        "avg_score": avg_score,
        "grade": grade,
        "grade_color": grade_color,
        "strongest_area": strongest_area,
        "weakest_area": weakest_area,
        "dominant_sentiment": dominant_sentiment,
        "breakdown": breakdown,
        "strong_count": len(strong_qs),
        "weak_count": len(weak_qs),
        "score_dist": score_dist,
        "weak_types": weak_types,
        "all_feedbacks": feedbacks,
    }


def _grade(avg):
    if avg >= 9:   return "Excellent",  "#16a34a"
    if avg >= 7.5: return "Good",       "#2563eb"
    if avg >= 6:   return "Average",    "#d97706"
    if avg >= 4:   return "Needs Work", "#dc2626"
    return          "Poor",             "#7f1d1d"


def _score_color(s):
    if s >= 8: return "#15803d"
    if s >= 5: return "#b45309"
    return "#b91c1c"


def _score_bg(s):
    if s >= 8: return "#dcfce7"
    if s >= 5: return "#fef3c7"
    return "#fee2e2"
