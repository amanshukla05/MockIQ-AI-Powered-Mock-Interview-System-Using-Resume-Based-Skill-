"""
utils/resume_parser.py
Extract text from PDF or TXT resume files.
"""

import re


def extract_text_from_pdf(filepath: str) -> str:
    """Extract text from a PDF file using PyPDF2."""
    try:
        import PyPDF2
        text = []
        with open(filepath, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text.append(page_text)
        return "\n".join(text)
    except ImportError:
        return "[PyPDF2 not installed. Run: pip install PyPDF2]"
    except Exception as e:
        return f"[Error reading PDF: {e}]"


def extract_text_from_txt(filepath: str) -> str:
    """Read plain text resume."""
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        return f"[Error reading file: {e}]"


def clean_resume_text(text: str) -> str:
    """Basic cleanup — remove extra whitespace, weird chars."""
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^\x20-\x7E\n]", " ", text)
    return text.strip()
