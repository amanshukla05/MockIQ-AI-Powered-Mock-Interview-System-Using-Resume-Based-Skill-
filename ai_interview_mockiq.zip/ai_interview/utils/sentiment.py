"""
utils/sentiment.py
Detect confidence/sentiment from answer text.
Uses simple lexicon-based approach (no external ML needed).
"""

CONFIDENT_WORDS = [
    "definitely", "certainly", "clearly", "absolutely", "confident",
    "I implemented", "I built", "I designed", "I led", "I achieved",
    "successfully", "proven", "demonstrated", "expertise", "I know",
    "in my experience", "I have", "I used", "I developed", "strong"
]

NERVOUS_WORDS = [
    "I think maybe", "not sure", "I don't know", "possibly", "might be",
    "I'm not certain", "I guess", "perhaps", "I believe maybe", "probably not",
    "I'm confused", "I don't remember", "I forgot", "it could be",
    "I'm not familiar", "never used", "haven't done"
]

FILLER_WORDS = [
    "um", "uh", "like", "you know", "basically", "literally",
    "kind of", "sort of", "i mean"
]


def detect_sentiment(text: str) -> str:
    """
    Returns: 'Confident', 'Neutral', or 'Nervous'
    """
    text_lower = text.lower()
    words = text_lower.split()
    total_words = max(len(words), 1)

    confident_score = sum(1 for w in CONFIDENT_WORDS if w.lower() in text_lower)
    nervous_score = sum(1 for w in NERVOUS_WORDS if w.lower() in text_lower)
    filler_count = sum(1 for w in FILLER_WORDS if w in text_lower)

    # Normalise filler ratio
    filler_ratio = filler_count / total_words

    # Adjust nervous score by filler density
    if filler_ratio > 0.05:
        nervous_score += 2

    # Length heuristic: very short answers = unsure
    if total_words < 30:
        nervous_score += 1

    if confident_score > nervous_score + 1:
        return "Confident"
    elif nervous_score > confident_score + 1:
        return "Nervous"
    else:
        return "Neutral"


def sentiment_color(sentiment: str) -> str:
    mapping = {
        "Confident": "#22c55e",
        "Neutral":   "#f59e0b",
        "Nervous":   "#ef4444"
    }
    return mapping.get(sentiment, "#888")
