"""
utils/skill_extractor.py
Match resume text against domain-specific skill lists.
"""

DOMAIN_SKILLS = {
    "Data Analyst": [
        "Python", "SQL", "Pandas", "NumPy", "Excel", "Power BI", "Tableau",
        "Statistics", "Machine Learning", "Data Visualization", "ETL", "R",
        "Matplotlib", "Seaborn", "Jupyter", "BigQuery", "Spark", "Airflow",
        "Data Cleaning", "EDA", "Regression", "Classification", "Clustering",
        "A/B Testing", "Google Analytics", "Looker", "dbt", "Snowflake"
    ],
    "Web Developer": [
        "JavaScript", "TypeScript", "React", "Vue", "Angular", "Next.js",
        "HTML", "CSS", "Tailwind", "Node.js", "Express", "REST APIs",
        "GraphQL", "MongoDB", "PostgreSQL", "MySQL", "Redis", "Docker",
        "Git", "Webpack", "Vite", "Jest", "Cypress", "Firebase", "AWS",
        "SASS", "Bootstrap", "WebSockets", "OAuth", "JWT"
    ],
    "Machine Learning Engineer": [
        "Python", "TensorFlow", "PyTorch", "Keras", "Scikit-learn",
        "Deep Learning", "NLP", "Computer Vision", "MLOps", "SQL",
        "Pandas", "Feature Engineering", "Transformers", "BERT", "GPT",
        "Hugging Face", "MLflow", "Kubeflow", "AWS SageMaker", "CUDA",
        "Docker", "Kubernetes", "FastAPI", "Model Deployment", "A/B Testing",
        "Reinforcement Learning", "XGBoost", "LightGBM", "ONNX", "Spark"
    ],
    "Backend Developer": [
        "Python", "Java", "Go", "Node.js", "C#", "Ruby", "PHP",
        "Django", "Flask", "FastAPI", "Spring Boot", "SQL", "PostgreSQL",
        "MySQL", "MongoDB", "Redis", "REST APIs", "GraphQL", "Docker",
        "Kubernetes", "Microservices", "RabbitMQ", "Kafka", "AWS", "GCP",
        "Git", "Linux", "Nginx", "gRPC", "JWT", "OAuth2"
    ],
    "DevOps Engineer": [
        "Docker", "Kubernetes", "AWS", "GCP", "Azure", "CI/CD",
        "Jenkins", "GitHub Actions", "GitLab CI", "Terraform", "Ansible",
        "Linux", "Bash", "Python", "Prometheus", "Grafana", "ELK Stack",
        "Nginx", "Helm", "Vault", "Consul", "ArgoCD", "Datadog",
        "Monitoring", "Logging", "Shell scripting", "Networking", "IAM"
    ],
    "Product Manager": [
        "Product Strategy", "Agile", "Scrum", "Roadmapping", "User Research",
        "A/B Testing", "Data Analysis", "SQL", "Stakeholder Management",
        "Figma", "JIRA", "Confluence", "KPIs", "OKRs", "User Stories",
        "PRD", "Market Research", "Competitive Analysis", "Go-to-Market",
        "Customer Journey", "Feature Prioritization", "RICE", "MoSCoW",
        "Analytics", "Funnel Optimization", "NPS", "Cohort Analysis"
    ]
}


def extract_skills(resume_text: str, domain: str) -> list:
    """
    Return a list of skills found in resume_text for the given domain.
    Falls back to top domain skills if nothing found.
    """
    skill_list = DOMAIN_SKILLS.get(domain, [])
    text_lower = resume_text.lower()
    found = [s for s in skill_list if s.lower() in text_lower]

    # Fallback: return top 6 skills for domain
    if not found:
        found = skill_list[:6]

    return found


def get_domain_core_skills(domain: str, n: int = 5) -> list:
    """Return top N skills for a domain (used in question prompts)."""
    return DOMAIN_SKILLS.get(domain, [])[:n]
